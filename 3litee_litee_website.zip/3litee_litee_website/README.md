# 3Litee / LITEE Website

A luxury Afrobeat artist website built for 3Litee.

## Files
- index.html — complete website
- assets/ — catalog and magazine images

## Publish
Upload the entire folder to a static hosting service such as GitHub Pages, Netlify, Vercel, or another web host. Keep the `assets` folder beside `index.html`.

## Customize
Edit the text in `index.html` to add official music links, social links, email, booking information, and your domain.
